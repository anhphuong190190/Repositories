/**
 * 
 */


    $(document).ready(function(){
    	$("button").click(function(){
            $.post("FindFood//addCart",
            {
            	
            },
            function(data,status){
                alert("Data: " + data + "\nStatus: " + status);
            });
        });

    });
    
    var carts = [];

    function cart(productId)
    {
    	carts.push(productId)
    	$('total-').value = carts.length
    }

    function show_cart()
    {
      $.ajax({
      type:'post',
      url:'allProduct.jsp',
      data:{
        showcart:"cart"
      },
      success:function(response) {
        document.getElementById("mycart").innerHTML=response;
        $("#mycart").slideToggle();
      }
     });

    }
	

