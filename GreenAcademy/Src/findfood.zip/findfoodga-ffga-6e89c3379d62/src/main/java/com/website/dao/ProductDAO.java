package com.website.dao;

import java.util.List;


import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.website.model.Product;

@Repository
public class ProductDAO {
	@Autowired
	private SessionFactory sessionfactory;
	
	public void setSessionfactory(SessionFactory sessionfactory) {
		this.sessionfactory = sessionfactory;
	}

	public List getAll() {
		Session session= this.sessionfactory.getCurrentSession();
		List proList = session.createQuery("from Product").list();
		return proList;
	}
	
	public Product add(Product pro){
		Session session= this.sessionfactory.getCurrentSession();
		session.persist(pro);
		return pro;
	}


}
