package com.website.dao;

import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.website.model.Cook;




@Repository
public class CookDAO {
	@Autowired
	SessionFactory sessionFactory;

	public void setSessionFactory(SessionFactory sessionFactory) {
		this.sessionFactory = sessionFactory;
	}
	
	public List getAll(){
		Session session = this.sessionFactory.getCurrentSession();
		List cooklist = session.createQuery("from Cook").list();
		return cooklist;
		
	}
	public Cook add(Cook cook){
		Session session = this.sessionFactory.getCurrentSession();
		session.persist(cook);
		return cook;
	}
	public Cook getCook(int id){
		Session session = this.sessionFactory.getCurrentSession();
		Cook cook = (Cook) session.get(Cook.class, new Integer(id));
		return cook;
	}
	
	public void updateCook(Cook cook){
		Session session = this.sessionFactory.getCurrentSession();
		session.update(cook);
	}

}
