package com.website.controller;

import java.io.IOException;

import java.io.UnsupportedEncodingException;
import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.util.Base64Utils;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;

import com.website.model.Category;
import com.website.model.Cook;
import com.website.model.Product;
import com.website.service.CategoryService;
import com.website.service.ProductService;

@Controller
public class ProductController {
	@Autowired
	ProductService productservice;
	CategoryService categoryservice;

	@RequestMapping(value = "/getAllProduct", method = RequestMethod.GET, headers = "Accept=application/json")
	public String getProducts(Model model) {
		List<Product> products = productservice.getAllProduct();
		// buildProducts(products);
		model.addAttribute("lop", products);
		return "allProduct";
	}

	// private void buildProducts(List<Product> products) {
	// for (Product product : products) {
	// Category category =
	// categoryservice.getCategoryByID(product.getCategory().getCategoryID());
	// product.setCategory(category);
	// }
	//
	// }

	@RequestMapping(value = "/newProduct", method = RequestMethod.GET, headers = "Accept=application/json")
	public String viewAddProduct(Model model) {
		Product product = new Product();
		model.addAttribute("product", product);
		return "addProduct";
	}

	@RequestMapping(value = "/addProduct", method = RequestMethod.POST, headers = "Accept=application/json")
	public String addProduct(@RequestParam("proName") String proname, @RequestParam("proPrice") double proprice,
			@RequestParam("proCategory") int procategory, @RequestParam("proCook") int procook,
			@RequestParam("proDesc") String prodesc, @RequestParam("img1") MultipartFile file1,
			@RequestParam("img2") MultipartFile file2, @RequestParam("img3") MultipartFile file3,
			@ModelAttribute("product") Product product) {

		try {
			product.setNameProduct(proname);
			product.setPrice(proprice);

			Category cate = new Category();
			cate.setCategoryID(procategory);
			product.setCategory(cate);

			Cook cook = new Cook();
			cook.setIdCook(procook);
			product.setCook(cook);

			product.setDescription(prodesc);

			byte[] data1 = file1.getBytes();
			byte[] data2 = file2.getBytes();
			byte[] data3 = file3.getBytes();
			product.setImagedata(data1);
			product.setImage2data(data2);
			product.setImage3data(data3);

			// encode to 64bit img data
			byte[] encode1 = Base64Utils.encode(data1);
			String base64Encode1 = new String(encode1, "UTF-8");
			product.setImgEnc64(base64Encode1);

			byte[] encode2 = Base64Utils.encode(data2);
			String base64Encode2 = new String(encode2, "UTF-8");
			product.setImg2Enc64(base64Encode2);

			byte[] encode3 = Base64Utils.encode(data3);
			String base64Encode3 = new String(encode3, "UTF-8");
			product.setImg3Enc64(base64Encode3);

		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		productservice.addProduct(product);
		return "redirect:/getAllProduct";
	}

	@RequestMapping(value = "/addCart", method = RequestMethod.POST, headers = "Accept=application/json")
	public int addCart(@RequestParam("carts") int[] carts) {
		int count = 0;
		
//		List<Product> products = productservice.getProductsByIds(carts);
//		"payment.jsp"
//		+ ""
//		+ "variable global javascript"
//		productservice.addCart(product);
		return count;
	}
}
