package com.website.springmvc.model;

public class StudentModel {

}
