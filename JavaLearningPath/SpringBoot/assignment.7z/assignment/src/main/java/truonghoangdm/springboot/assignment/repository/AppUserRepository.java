package truonghoangdm.springboot.assignment.repository;

import org.springframework.data.repository.CrudRepository;

import truonghoangdm.springboot.assignment.security.entity.AppUser;

public interface AppUserRepository extends CrudRepository<AppUser, Long> {
	AppUser findByUsername(String username);
}