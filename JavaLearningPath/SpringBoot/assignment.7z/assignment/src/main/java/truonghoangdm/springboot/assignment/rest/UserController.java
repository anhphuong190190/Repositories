package truonghoangdm.springboot.assignment.rest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import truonghoangdm.springboot.assignment.dto.UserDto;
import truonghoangdm.springboot.assignment.service.IUserService;

@RestController
@RequestMapping("/user")
public class UserController {
	@Autowired
	private IUserService userService;
	/**
	 * Get userName by id
	 * All users can use
	 * @param id
	 * @return name
	 */
	@RequestMapping(method = RequestMethod.GET, value = "/getName/{id}")
	public String getUserName(@PathVariable long id) {
		return userService.getNameById(id);
	}

	/**
	 * Get startDate by id
	 * Admin & Mod can use
	 * @param id
	 * @return StartDate
	 */
	@RequestMapping(method = RequestMethod.GET, value = "/getStartDate/{id}")
	public String getUserStartDate(@PathVariable long id) {
		return userService.getStartDateById(id);
	}

	/**
	 * Get all user detail by id.
	 * Only admin can use
	 * @param id
	 * @return UserDto
	 */
	@RequestMapping(method = RequestMethod.GET, value = "/detail/{id}")
	public UserDto getUserDetail(@PathVariable long id) {
		return userService.getUserDTODetails(id);
	}
}