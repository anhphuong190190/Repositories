package truonghoangdm.springboot.assignment.service.impl;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import truonghoangdm.springboot.assignment.dto.UserDto;
import truonghoangdm.springboot.assignment.entity.User;
import truonghoangdm.springboot.assignment.repository.UserRepository;
import truonghoangdm.springboot.assignment.service.IUserService;
import truonghoangdm.springboot.assignment.utils.AppUtil;

@Service
public class UserService implements IUserService {

	public static final String FORMAT_DATE_YYYYMMDD = "yyyy-MM-dd";

	@Autowired
	UserRepository userRepository;

	public User getById(Long id) {
		Optional<User> userOpt = userRepository.findById(id);
		if (userOpt.isPresent()) {
			return userOpt.get();
		} else {
			return null;
		}
	}

	@Override
	public String getNameById(Long id) {
		User user = getById(id);
		if (user != null) {
			return user.getName();
		}
		return null;
	}

	@Override
	public String getStartDateById(Long id) {
		User user = getById(id);
		if (user != null) {
			return AppUtil.convertStringToDate(user.getStart_date(), FORMAT_DATE_YYYYMMDD);
		}
		return null;
	}

	@Override
	public UserDto getUserDTODetails(Long id) {
		User user = getById(id);
		if (user != null) {
			return convertEntitytoDto(user);
		}
		return null;
	}

	private UserDto convertEntitytoDto(User user) {
		UserDto result = new UserDto();
		result.setId(user.getId());
		result.setName(user.getName());
		result.setStart_date(AppUtil.convertStringToDate(user.getStart_date(), FORMAT_DATE_YYYYMMDD));
		result.setLoyal_point(AppUtil.calLoyalPoint(user.getStart_date()));
		return result;
	}
}
