package truonghoangdm.springboot.assignment.utils;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

public class AppUtil {

	public static long calLoyalPoint(Date startDate) {
		long minusDate = (minusDate(startDate, Calendar.getInstance().getTime()) + 1) * 5;
		return minusDate;
	}

	private static long minusDate(Date start, Date end) {
		Date startDate = new Date(start.getYear(), start.getMonth(), start.getDate());
		Date endDate = new Date(end.getYear(), end.getMonth(), end.getDate());
		return (endDate.getTime() - startDate.getTime()) / (24 * 3600 * 1000);
	}

	/**
	 * Method convert String to Date with dateFormat
	 * @param date
	 * @param dateFormat
	 * @return String
	 */
	public static String convertStringToDate(Date date, String dateFormat) {
		if (date == null || dateFormat == null) {
			return "";
		}
		String dateString = "";
		try {
			SimpleDateFormat outputDateFormat = new SimpleDateFormat(dateFormat);
			dateString = outputDateFormat.format(date);
		} catch (Exception ex) {
			return "";
		}
		return dateString;
	}

}