package truonghoangdm.springboot.assignment.service;

import org.springframework.stereotype.Component;

import truonghoangdm.springboot.assignment.dto.UserDto;

@Component
public interface IUserService {
	public String getNameById(Long id);
	public String getStartDateById(Long id);
	public UserDto getUserDTODetails(Long id);
	
}
