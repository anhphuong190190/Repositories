package truonghoangdm.springboot.assignment.dto;

public class UserDto {
	private Long id;
	private String name;
	private String start_date;
	private long loyal_point;

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getStart_date() {
		return start_date;
	}

	public void setStart_date(String start_date) {
		this.start_date = start_date;
	}

	public long getLoyal_point() {
		return loyal_point;
	}

	public void setLoyal_point(long loyal_point) {
		this.loyal_point = loyal_point;
	}
}
