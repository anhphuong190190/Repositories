package truonghoangdm.springboot.assignment.test.rest;

import static org.hamcrest.Matchers.is;
import static org.springframework.security.test.web.servlet.request.SecurityMockMvcRequestPostProcessors.httpBasic;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.content;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.json.JacksonJsonParser;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.security.web.FilterChainProxy;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.ResultActions;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;
import org.springframework.web.context.WebApplicationContext;

import truonghoangdm.springboot.assignment.SpringbootAssignmentApplication;

@RunWith(SpringRunner.class)
@SpringBootTest(classes = SpringbootAssignmentApplication.class)
@ActiveProfiles("mvc")
public class UserControllerTests {

	@Autowired
	private WebApplicationContext wac;

	@Autowired(required = true)
	private FilterChainProxy springSecurityFilterChain;

	private MockMvc mockMvc;

	private static final String CLIENT_ID = "testjwtclientid";
	private static final String CLIENT_SECRET = "XY7kmzoNzl100";
	private static final String CONTENT_TYPE = "application/json;charset=UTF-8";
	private static final String USERNAME_ADMIN = "admin";
	private static final String USERNAME_MOD = "mod";
	private static final String USERNAME_USER = "user";
	private static final String PASSWORD = "password";
	private static final String PASSWORD_VALID = "XY7kmzoNzl100";
	private static final String HEADER_REQUEST_KEY_AUTHORIZATION = "Authorization";
	private static final String HEADER_REQUEST_VALUE_AUTHORIZATION = "Bearer ";
	private static final String EXPECTED_STARTDATE = "2018-06-14";
	private static final String PATH_GET_NAME_BY_ID = "/user/getName/1";
	private static final String PATH_GET_STARTDATE_BY_ID = "/user/getStartDate/1";
	private static final String PATH_GET_USERS_BY_ID = "/user/detail/1";
	private static final String PATH_POST_OAUTH_TOKEN = "/oauth/token";

	@Before
	public void setup() {
		this.mockMvc = MockMvcBuilders.webAppContextSetup(this.wac).addFilter(springSecurityFilterChain).build();
	}

	private String obtainAccessToken(String username, String password) throws Exception {
		final MultiValueMap<String, String> params = new LinkedMultiValueMap<>();
		params.add("grant_type", PASSWORD);
		params.add("client_id", CLIENT_ID);
		params.add("username", username);
		params.add("password", password);

		ResultActions result = mockMvc
				.perform(post(PATH_POST_OAUTH_TOKEN).params(params).with(httpBasic(CLIENT_ID, CLIENT_SECRET))
						.accept(CONTENT_TYPE))
				.andExpect(status().isOk()).andExpect(content().contentType(CONTENT_TYPE));
		String resultString = result.andReturn().getResponse().getContentAsString();

		JacksonJsonParser jsonParser = new JacksonJsonParser();
		return jsonParser.parseMap(resultString).get("access_token").toString();
	}

	@Test
	public void givenToken_whenGetNameSecureRequest_thenOk() throws Exception {
		final String accessToken = obtainAccessToken(USERNAME_ADMIN, PASSWORD_VALID);
		mockMvc.perform(get(PATH_GET_NAME_BY_ID).header(HEADER_REQUEST_KEY_AUTHORIZATION, HEADER_REQUEST_VALUE_AUTHORIZATION + accessToken)
				.accept(CONTENT_TYPE)).andExpect(status().isOk()).andExpect(content().contentType(CONTENT_TYPE))
				.andExpect(content().string("test"));
	}

	@Test
	public void givenNoToken_whenGetSecureRequest_thenUnauthorized() throws Exception {
		mockMvc.perform(get(PATH_GET_STARTDATE_BY_ID)).andExpect(status().isUnauthorized());
	}

	@Test
	public void givenInvalidRole_whenGetStartDateSecureRequest_thenForbidden() throws Exception {
		final String accessToken = obtainAccessToken(USERNAME_USER, PASSWORD_VALID);
		mockMvc.perform(get(PATH_GET_STARTDATE_BY_ID).header(HEADER_REQUEST_KEY_AUTHORIZATION, HEADER_REQUEST_VALUE_AUTHORIZATION + accessToken))
				.andExpect(status().isForbidden());
	}

	@Test
	public void givenRoleAdmin_whenGetStartDateSecureRequest_thenOK() throws Exception {
		final String accessToken = obtainAccessToken(USERNAME_ADMIN, PASSWORD_VALID);
		mockMvc.perform(
				get(PATH_GET_STARTDATE_BY_ID).header(HEADER_REQUEST_KEY_AUTHORIZATION, HEADER_REQUEST_VALUE_AUTHORIZATION + accessToken).accept(CONTENT_TYPE))
				.andExpect(status().isOk()).andExpect(content().contentType(CONTENT_TYPE))
				.andExpect(jsonPath("$", is(EXPECTED_STARTDATE)));

	}

	@Test
	public void givenRoleMod_whenGetStartDateSecureRequest_thenOK() throws Exception {
		final String accessToken = obtainAccessToken(USERNAME_MOD, PASSWORD_VALID);
		mockMvc.perform(
				get(PATH_GET_STARTDATE_BY_ID).header(HEADER_REQUEST_KEY_AUTHORIZATION, HEADER_REQUEST_VALUE_AUTHORIZATION + accessToken).accept(CONTENT_TYPE))
				.andExpect(status().isOk()).andExpect(content().contentType(CONTENT_TYPE))
				.andExpect(jsonPath("$", is(EXPECTED_STARTDATE)));
	}

	@Test
	public void givenToken_whenGetDetailSecureRequest_thenOk() throws Exception {
		final String accessToken = obtainAccessToken(USERNAME_ADMIN, PASSWORD_VALID);
		mockMvc.perform(get(PATH_GET_USERS_BY_ID).header(HEADER_REQUEST_KEY_AUTHORIZATION, HEADER_REQUEST_VALUE_AUTHORIZATION + accessToken).accept(CONTENT_TYPE))
				.andExpect(status().isOk()).andExpect(content().contentType(CONTENT_TYPE))
				.andExpect(jsonPath("$.id", is(1))).andExpect(jsonPath("$.name", is("test")))
				.andExpect(jsonPath("$.loyal_point", is(10)))
				.andExpect(jsonPath("$.start_date", is(EXPECTED_STARTDATE)));

	}

	@Test
	public void givenInvalidRole_whenGetDetailSecureRequest_thenOk() throws Exception {
		final String accessToken = obtainAccessToken(USERNAME_MOD, PASSWORD_VALID);
		mockMvc.perform(get(PATH_GET_USERS_BY_ID).header(HEADER_REQUEST_KEY_AUTHORIZATION, HEADER_REQUEST_VALUE_AUTHORIZATION + accessToken))
				.andExpect(status().isForbidden());
	}
}