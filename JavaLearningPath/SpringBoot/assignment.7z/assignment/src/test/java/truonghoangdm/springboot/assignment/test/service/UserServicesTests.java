package truonghoangdm.springboot.assignment.test.service;

import static org.junit.Assert.assertEquals;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Optional;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.context.TestConfiguration;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.context.annotation.Bean;
import org.springframework.test.context.junit4.SpringRunner;

import truonghoangdm.springboot.assignment.dto.UserDto;
import truonghoangdm.springboot.assignment.entity.User;
import truonghoangdm.springboot.assignment.repository.UserRepository;
import truonghoangdm.springboot.assignment.service.IUserService;
import truonghoangdm.springboot.assignment.service.impl.UserService;
import truonghoangdm.springboot.assignment.utils.AppUtil;

@RunWith(SpringRunner.class)
@SpringBootTest
public class UserServicesTests {

	public static final String FORMAT_DATE_YYYYMMDD = "yyyy-MM-dd";

	@TestConfiguration
	static class EmployeeServiceImplTestContextConfiguration {

		@Bean
		public IUserService userServices() {
			return new UserService();
		}
	}

	@Autowired
	private IUserService userServices;

	@MockBean
	private UserRepository userRepository;

	@Test
	public void testGetNameByIdHaveFounds() {
		Optional<User> userOpt = Optional.of(createUser());
		Mockito.when(userRepository.findById(1L)).thenReturn(userOpt);
		String result = userServices.getNameById(1L);
		assertEquals(result, userOpt.get().getName());

	}

	@Test
	public void testGetNameByIdNoFounds() {
		Optional<User> userOpt = Optional.ofNullable(null);
		Mockito.when(userRepository.findById(1L)).thenReturn(userOpt);
		String result = userServices.getNameById(1L);
		assertEquals(result, null);
	}

	@Test
	public void testGetStartDateByIdHaveFounds() {
		Date start_date = createStartDate();
		Optional<User> userOpt = Optional.of(createUser());
		Mockito.when(userRepository.findById(1L)).thenReturn(userOpt);

		String result = userServices.getStartDateById(1L);

		SimpleDateFormat sdf = new SimpleDateFormat(FORMAT_DATE_YYYYMMDD);
		assertEquals(sdf.format(start_date).equals(result), true);

	}

	@Test
	public void testGetStartDateByIdNotFound() {
		Optional<User> userOpt = Optional.ofNullable(null);
		Mockito.when(userRepository.findById(1L)).thenReturn(userOpt);
		assertEquals(userServices.getStartDateById(1L), null);
	}

	@Test
	public void testGetUserDTODetailsHaveFounds() {
		Optional<User> userOpt = Optional.of(createUser());
		Mockito.when(userRepository.findById(1L)).thenReturn(userOpt);

		UserDto result = userServices.getUserDTODetails(1L);

		assertEquals(result.getId(), userOpt.get().getId());
		assertEquals(result.getName(), userOpt.get().getName());
		assertEquals(result.getStart_date(),
				AppUtil.convertStringToDate(userOpt.get().getStart_date(), FORMAT_DATE_YYYYMMDD));

		long expectedLoyalPoint = AppUtil.calLoyalPoint(userOpt.get().getStart_date());
		long actualLoyalPoint = result.getLoyal_point();
		assertEquals(expectedLoyalPoint, actualLoyalPoint);

	}

	@Test
	public void testGetUserDTODetailsNoFounds() {
		Optional<User> userOpt = Optional.ofNullable(null);
		Mockito.when(userRepository.findById(1L)).thenReturn(userOpt);

		UserDto result = userServices.getUserDTODetails(1L);
		assertEquals(result, null);
	}

	private Date createStartDate() {
		SimpleDateFormat sdf = new SimpleDateFormat(FORMAT_DATE_YYYYMMDD);
		String dateInString = "2018-06-14";
		Date date = null;
		try {
			date = sdf.parse(dateInString);
		} catch (ParseException e) {
			e.printStackTrace();
		}
		return date;
	}

	private User createUser() {
		User user = new User();
		user.setId(Long.valueOf(1));
		user.setName("test");
		user.setStart_date(createStartDate());
		return user;
	}

}
