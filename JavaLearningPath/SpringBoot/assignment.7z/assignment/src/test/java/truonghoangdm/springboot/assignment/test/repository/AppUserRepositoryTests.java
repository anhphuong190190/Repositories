package truonghoangdm.springboot.assignment.test.repository;



import static org.assertj.core.api.Assertions.assertThat;

import java.util.ArrayList;
import java.util.List;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.jdbc.AutoConfigureTestDatabase;
import org.springframework.boot.test.autoconfigure.jdbc.AutoConfigureTestDatabase.Replace;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;
import org.springframework.boot.test.autoconfigure.orm.jpa.TestEntityManager;
import org.springframework.test.context.junit4.SpringRunner;

import truonghoangdm.springboot.assignment.repository.AppUserRepository;
import truonghoangdm.springboot.assignment.security.entity.AppUser;
import truonghoangdm.springboot.assignment.security.entity.Role;

@RunWith(SpringRunner.class)
@AutoConfigureTestDatabase(replace = Replace.NONE)
@DataJpaTest
public class AppUserRepositoryTests {
	@Autowired
    private TestEntityManager entityManager ;
 
    @Autowired
    private AppUserRepository appUserRepository;
    
    @Test
    public void whenFindByName_thenReturnEmployee() {
        // given
    	AppUser appUser = new AppUser();
    	appUser.setFirstName("firtname");
    	appUser.setLastName("firtname");
    	appUser.setPassword("password");
    	appUser.setUsername("username");
    	List<Role> lstRoles = new ArrayList<Role>();
		Role role = new Role();
		role.setRoleName("ADMIN");
		role.setDescription("Role Admin");
		appUser.setRoles(lstRoles);
        entityManager.persist(appUser);
        entityManager.flush();
     
        // when
        AppUser found = appUserRepository.findByUsername(appUser.getUsername());
     
        // then
        assertThat(found.getUsername()).isEqualTo(appUser.getUsername());
    }
}
