package truonghoangdm.springboot.assignment.test.service;

import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.Assert.assertEquals;

import java.util.ArrayList;
import java.util.List;

import org.junit.Rule;
import org.junit.Test;
import org.junit.rules.ExpectedException;
import org.junit.runner.RunWith;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.context.TestConfiguration;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.context.annotation.Bean;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.test.context.junit4.SpringRunner;

import truonghoangdm.springboot.assignment.repository.AppUserRepository;
import truonghoangdm.springboot.assignment.security.entity.AppUser;
import truonghoangdm.springboot.assignment.security.entity.Role;
import truonghoangdm.springboot.assignment.service.impl.AppUserDetailsService;

@RunWith(SpringRunner.class)
@SpringBootTest
public class AppUserDetailsServiceTests {
	@TestConfiguration
	static class AppUserDetailsServiceTestContextConfiguration {

		@Bean
		public UserDetailsService userDetailsService() {
			return new AppUserDetailsService();
		}
	}

	@Autowired
	private UserDetailsService userDetailsService;

	@MockBean
	private AppUserRepository userRepository;
	
	@Rule
    public ExpectedException thrown = ExpectedException.none();

	@Test
	public void testLoadUserByUsernameHaveRecord() {
		// Set data for AppUser
		AppUser user = new AppUser();
		user.setUsername("admin");
		user.setId(2L);
		user.setFirstName("firtname");
		user.setLastName("lastname");
		user.setPassword("password");
		List<Role> lstRoles = new ArrayList<Role>();
		Role role = new Role();
		role.setRoleName("ROLE_ADMIN");
		role.setId(2L);
		role.setDescription("Role Admin");
		lstRoles.add(role);
		user.setRoles(lstRoles);
		
		Mockito.when(userRepository.findByUsername("admin")).thenReturn(user);
		
		UserDetails result = userDetailsService.loadUserByUsername("admin");
		assertEquals(user.getUsername(), result.getUsername());
		assertEquals(user.getPassword(),result.getPassword());
		assertThat(user.getRoles().get(0).equals("ROLE_ADMIN"));
	}

	@Test()
	public void testLoadUserByUsernameThrowException() {
		Mockito.when(userRepository.findByUsername("admin")).thenReturn(null);
		thrown.expect(UsernameNotFoundException.class);
		userDetailsService.loadUserByUsername("admin");
	}
}
