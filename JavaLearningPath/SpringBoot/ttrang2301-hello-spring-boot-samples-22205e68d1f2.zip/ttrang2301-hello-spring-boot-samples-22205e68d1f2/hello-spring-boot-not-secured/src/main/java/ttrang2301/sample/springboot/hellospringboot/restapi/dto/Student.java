package ttrang2301.sample.springboot.hellospringboot.restapi.dto;

public class Student {

	public int id;
	public String name;
	public String clazz;

	public Student(int id, String name, String clazz) {
		super();
		this.id = id;
		this.name = name;
		this.clazz = clazz;
	}
}
