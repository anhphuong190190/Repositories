package ttrang2301.sample.springboot.hellospringboot.restapi;

import java.util.List;
import java.util.stream.Collectors;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import ttrang2301.sample.springboot.hellospringboot.dao.StudentRepository;
import ttrang2301.sample.springboot.hellospringboot.restapi.dto.Response;
import ttrang2301.sample.springboot.hellospringboot.restapi.dto.Student;
import ttrang2301.sample.springboot.hellospringboot.restapi.dto.StudentIdResponse;
import ttrang2301.sample.springboot.hellospringboot.restapi.dto.StudentNameResponse;
import ttrang2301.sample.springboot.hellospringboot.restapi.dto.StudentResponse;

@RestController
@RequestMapping(value = StudentController.URI.API)
public class StudentController {

	public static final class URI {

		public static final String API = "/api/student";

		public static final String RESOURCE_PROFILE = "/profile";
		public static final String RESOURCE_ID = "/id";
		public static final String RESOURCE_NAME = "/name";
	}

	private static final Logger LOGGER = LoggerFactory.getLogger(StudentController.class);

	@Autowired
	private StudentRepository studentRepository;

	@RequestMapping(method = RequestMethod.GET, value = URI.RESOURCE_PROFILE)
	public StudentResponse getStudent(@RequestParam(required = false, name = "class") Integer classId) {
		LOGGER.info("Request Student");
		List<ttrang2301.sample.springboot.hellospringboot.dao.entity.Student> jpas;
		if (classId == null) {
			jpas = studentRepository.findAll();
		} else {
			jpas = studentRepository.findByClazzId(classId);
		}
		List<Student> dtos = jpas.stream().map(jpa -> new Student(jpa.getId(), jpa.getName(), jpa.getClazz().getName()))
				.collect(Collectors.toList());
		return new StudentResponse(Response.SUCCESS, "success", dtos);
	}

	@RequestMapping(method = RequestMethod.GET, value = URI.RESOURCE_ID)
	public StudentIdResponse getStudentIds(@RequestParam(required = false, name = "class") Integer classId) {
		LOGGER.info("Request Student IDs");
		List<ttrang2301.sample.springboot.hellospringboot.dao.entity.Student> jpas;
		if (classId == null) {
			jpas = studentRepository.findAll();
		} else {
			jpas = studentRepository.findByClazzId(classId);
		}
		List<Integer> dtos = jpas.stream().map(jpa -> jpa.getId()).collect(Collectors.toList());
		return new StudentIdResponse(Response.SUCCESS, "success", dtos);
	}

	@RequestMapping(method = RequestMethod.GET, value = URI.RESOURCE_NAME)
	public StudentNameResponse getStudentNames(@RequestParam(required = false, name = "class") Integer classId) {
		LOGGER.info("Request Student Names");
		List<ttrang2301.sample.springboot.hellospringboot.dao.entity.Student> jpas;
		if (classId == null) {
			jpas = studentRepository.findAll();
		} else {
			jpas = studentRepository.findByClazzId(classId);
		}
		List<String> dtos = jpas.stream().map(jpa -> jpa.getName()).collect(Collectors.toList());
		return new StudentNameResponse(Response.SUCCESS, "success", dtos);
	}

}
