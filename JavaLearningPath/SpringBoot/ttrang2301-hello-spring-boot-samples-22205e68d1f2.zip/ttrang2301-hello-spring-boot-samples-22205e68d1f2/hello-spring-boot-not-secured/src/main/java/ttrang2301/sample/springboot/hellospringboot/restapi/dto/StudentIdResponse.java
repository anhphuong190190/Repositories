package ttrang2301.sample.springboot.hellospringboot.restapi.dto;

import java.util.List;

public class StudentIdResponse extends Response {
	public List<Integer> ids;

	public StudentIdResponse(boolean success, String message, List<Integer> ids) {
		super(success, message);
		this.ids = ids;
	}
}
