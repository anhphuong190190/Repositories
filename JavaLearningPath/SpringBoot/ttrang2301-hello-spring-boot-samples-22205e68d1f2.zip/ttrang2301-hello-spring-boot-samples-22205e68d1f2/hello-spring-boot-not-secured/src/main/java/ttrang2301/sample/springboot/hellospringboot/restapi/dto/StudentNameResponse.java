package ttrang2301.sample.springboot.hellospringboot.restapi.dto;

import java.util.List;

public class StudentNameResponse extends Response {
	public List<String> names;

	public StudentNameResponse(boolean success, String message, List<String> names) {
		super(success, message);
		this.names = names;
	}

}
