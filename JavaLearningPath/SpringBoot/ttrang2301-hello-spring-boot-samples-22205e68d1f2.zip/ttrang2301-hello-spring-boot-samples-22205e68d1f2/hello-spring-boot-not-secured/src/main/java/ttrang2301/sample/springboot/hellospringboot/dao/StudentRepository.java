package ttrang2301.sample.springboot.hellospringboot.dao;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import ttrang2301.sample.springboot.hellospringboot.dao.entity.Student;

public interface StudentRepository extends JpaRepository<Student, Integer> {

	public List<Student> findAll();
	public List<Student> findByClazzId(int clazzId);

}
