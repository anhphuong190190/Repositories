package ttrang2301.sample.springboot.hellospringboot;

import javax.annotation.PostConstruct;

import org.apache.catalina.startup.Tomcat;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.autoconfigure.condition.ConditionalOnClass;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.context.annotation.Configuration;

@Configuration
// Only load when Tomcat is on classpath
@ConditionalOnClass(Tomcat.class)
// Only load when property log-tomcat-version=true; if not set, default value is
// true
@ConditionalOnProperty(name = "log-tomcat-version", matchIfMissing = true)
public class LogTomcatVersionAutoConfiguration {
	final static Logger LOGGER = LoggerFactory.getLogger(LogTomcatVersionAutoConfiguration.class);

	@PostConstruct
	public void logTomcatVersion() {
		LOGGER.info("========= Tomcat =========");
		LOGGER.info("== v" + Tomcat.class.getPackage().getImplementationVersion());
		LOGGER.info("==========================");
	}
}
