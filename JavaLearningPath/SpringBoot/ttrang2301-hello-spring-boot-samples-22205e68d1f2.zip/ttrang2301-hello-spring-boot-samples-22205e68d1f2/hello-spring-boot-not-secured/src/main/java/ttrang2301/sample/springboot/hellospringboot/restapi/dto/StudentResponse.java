package ttrang2301.sample.springboot.hellospringboot.restapi.dto;

import java.util.List;

public class StudentResponse extends Response {
	public List<Student> students;

	public StudentResponse(boolean success, String message, List<Student> students) {
		super(success, message);
		this.students = students;
	}
}
