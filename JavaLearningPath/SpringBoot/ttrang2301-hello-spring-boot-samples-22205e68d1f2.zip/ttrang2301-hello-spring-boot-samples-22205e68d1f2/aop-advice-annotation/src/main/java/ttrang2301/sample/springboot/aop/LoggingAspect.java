package ttrang2301.sample.springboot.aop;

import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.springframework.stereotype.Component;

/**
 * Where we add implementation of annotation {@link LogExecutionTime}
 * 
 * @author tranglett1
 *
 */
@Aspect
// Be detected by Spring
@Component
public class LoggingAspect {

	/**
	 * 
	 * Advice to print out execution time of a method annotated with
	 * {@link LogExecutionTime}
	 * 
	 * @param joinPoint
	 *            executing method which has been annotated with
	 *            {@link LogExecutionTime}
	 * @return
	 * @throws Throwable
	 */
	// @Around("@annotation(LogExecutionTime)"): Advice to add extra code before and
	// after any method which is annotated
	// with @LogExecutionTime
	@Around("@annotation(LogExecutionTime)")
	public Object logExecutionTime(ProceedingJoinPoint joinPoint) throws Throwable {

		// Record start time
		long start = System.currentTimeMillis();

		// Execute method
		Object proceed = joinPoint.proceed();

		// Record end time
		long executionTime = System.currentTimeMillis() - start;

		// Print out execution time
		System.out.println(joinPoint.getSignature() + " executed in " + executionTime + "ms");

		return proceed;
	}

}
