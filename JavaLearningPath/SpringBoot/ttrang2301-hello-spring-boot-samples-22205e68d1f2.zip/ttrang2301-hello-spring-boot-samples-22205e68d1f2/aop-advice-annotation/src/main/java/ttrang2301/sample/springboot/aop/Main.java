package ttrang2301.sample.springboot.aop;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.context.event.ApplicationReadyEvent;
import org.springframework.context.event.EventListener;

/**
 * AOP is a way for adding behavior to existing code without modifying that code
 * 
 * @author tranglett1
 *
 */
@SpringBootApplication
public class Main {

	@Autowired
	private SleepingBeautyService sampleService;

	public static void main(String[] args) {
		SpringApplication.run(Main.class, args);
	}

	// This method will be called after Application started
	@EventListener(ApplicationReadyEvent.class)
	public void doSomethingAfterStartup() throws Exception {
		System.out.println("Call service start");
		sampleService.serve();
		System.out.println("Call service end");
	}

}
