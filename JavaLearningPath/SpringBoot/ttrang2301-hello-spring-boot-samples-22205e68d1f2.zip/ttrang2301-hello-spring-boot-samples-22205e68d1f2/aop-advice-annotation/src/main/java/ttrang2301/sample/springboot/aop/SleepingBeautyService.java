package ttrang2301.sample.springboot.aop;

import org.springframework.stereotype.Component;

@Component
public class SleepingBeautyService {

	@LogExecutionTime
	public void serve() throws Exception {
		Thread.sleep(2000);
		throw new Exception("I'm fail ^___^");
	}

}
