package ttrang2301.sample.springboot.aop;

import java.lang.annotation.Retention;
import java.lang.annotation.Target;
import java.lang.annotation.ElementType;
import java.lang.annotation.RetentionPolicy;

/**
 * This annotation is applied for method only, and available to the JVM at
 * runtime
 * 
 * @author tranglett1
 *
 */
// Applied for method only
@Target(ElementType.METHOD)
// Available to the JVM at runtime
@Retention(RetentionPolicy.RUNTIME)
public @interface LogExecutionTime {

}
