package vuong.springboot.assignment;

import java.io.IOException;
import static org.assertj.core.api.Assertions.assertThat;

import org.json.JSONException;
import org.json.JSONObject;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.MediaType;
import org.springframework.test.context.TestPropertySource;
import org.springframework.test.context.jdbc.Sql;
import org.springframework.test.context.jdbc.Sql.ExecutionPhase;
import org.springframework.test.context.jdbc.SqlGroup;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.web.reactive.server.WebTestClient;
import org.springframework.web.reactive.function.BodyInserters;

import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.RequestBody;
import okhttp3.Response;
@RunWith(SpringRunner.class)
@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.DEFINED_PORT)
@TestPropertySource("classpath:application.properties")
@SqlGroup({
    @Sql(executionPhase = ExecutionPhase.BEFORE_TEST_METHOD, scripts = "classpath:data.sql") })
public class RestUserControllerTest {

	
	@Autowired
	private WebTestClient webTestClient;

	@Before
	public void setup(){
		
	}
	
	@After
	public void tearDown(){
		
	}
	
	@Test
	public void testHealthCheck() {
		webTestClient
			// Create a GET request to test an endpoint
			.get().uri("/actuator/health")
			.accept(MediaType.APPLICATION_JSON)
			.exchange()
			// and use the dedicated DSL to test assertions against the response
			.expectStatus().isOk()
			.expectBody(String.class).isEqualTo("{\"status\":\"UP\"}");
	}
	
	@Test
	public void testGetDataWithToken() {
		
		OkHttpClient client = new OkHttpClient();
		String token = null;
		okhttp3.MediaType mediaType = okhttp3.MediaType.parse("application/octet-stream");
		RequestBody body = RequestBody.create(mediaType, "{}");
		Request request = new Request.Builder()
		  .url("http://localhost:9999/oauth/token?grant_type=password&username=admin&password=password")
		  .post(body)
		  .addHeader("Content-Type", "application/json")
		  .addHeader("Authorization", "Basic dGVzdGp3dGNsaWVudGlkOnBhc3N3b3Jk")
		  .build();

		try {
			Response response = client.newCall(request).execute();
			JSONObject jsonObject = new JSONObject(response.body().string());
			token = jsonObject.getString("access_token");
		} catch (IOException e) {
			e.printStackTrace();
		} catch (JSONException e) {
			e.printStackTrace();
		}
		
		assertThat(token).isNotNull();
		//assertThat(token).isEqualTo("sdsd");
		
		webTestClient
			// Create a GET request to test an endpoint
			.get().uri("/private/user/getName/2")
			.header("Authorization", "Bearer "+ token)
			.header("Content-Type", "application/json")
			.exchange()
			// and use the dedicated DSL to test assertions against the response
			.expectStatus().isOk()
			.expectBody(String.class).isEqualTo("{\"name\":\"Test\"}");
		
		webTestClient
		// Create a GET request to test an endpoint
		.get().uri("/private/user/getStartDate/2")
		.header("Authorization", "Bearer "+ token)
		.header("Content-Type", "application/json")
		.exchange()
		// and use the dedicated DSL to test assertions against the response
		.expectStatus().isOk()
		.expectBody(String.class).isEqualTo("{\"start_date\":\"2017-12-31T17:00:00.000+0000\"}");
		
//		webTestClient
//		// Create a GET request to test an endpoint
//		.post().uri("/private/user/detail/1")
//		//.header("Authorization", "Basic dGVzdGp3dGNsaWVudGlkOnBhc3N3b3Jk")
//		.header("Content-Type", "application/json")
//		.body(BodyInserters.empty())
//		.exchange()
//		// and use the dedicated DSL to test assertions against the response
//		.expectStatus().isOk()
//		.expectBody(String.class).isEqualTo("{\"status\":\"UP\"}");
	}
}
