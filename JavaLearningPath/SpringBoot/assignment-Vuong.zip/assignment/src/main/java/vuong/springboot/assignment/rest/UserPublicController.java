package vuong.springboot.assignment.rest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import vuong.springboot.assignment.service.UserService;

@RestController
@RequestMapping("/public/user")
public class UserPublicController {
	@Autowired
	private UserService userService;
/*
	@RequestMapping(method = RequestMethod.GET, value = "/getName/{id}")
	public String getUserName(@PathVariable long id) {
		return userService.getNameById(id);
	}*/
}