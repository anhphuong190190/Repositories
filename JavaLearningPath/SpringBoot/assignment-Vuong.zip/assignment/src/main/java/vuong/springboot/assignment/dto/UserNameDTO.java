package vuong.springboot.assignment.dto;

public class UserNameDTO implements IClientResponse {
	private String name;

	public UserNameDTO(String name) {
		super();
		this.name = name;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

}
