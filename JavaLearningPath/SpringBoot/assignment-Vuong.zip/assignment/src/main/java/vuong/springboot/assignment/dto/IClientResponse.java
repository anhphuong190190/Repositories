package vuong.springboot.assignment.dto;

public interface IClientResponse {

}
